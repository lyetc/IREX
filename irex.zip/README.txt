Subject: Manpage for IRE and IREX
Subject: README  for IRE and IREX

DEMONSTRATION: https://youtu.be/D9eh6VU5flg

WARNING: While running IRE/IREX, you can 
         still calculate with the stack
         BUT their contents will probably
         be replaced since IRE implements
         its own ISG and DSE and these 
         calculate using the stack.          

WHEN
22Sep2024

WHO
IRE is Indirect Register Explorer for Free42 {and maybe HP-42S}
IREX is IRE Extended or IRE+MENU2.
MENU2 is the unprotected/unsafe operations
      meant for diehard users who just want 
      to get things done right away 
      sans formalities. 
You can load either IRE or IREX. They both
behave the same way UNTIL you SF 02.
If you think you might need what MENU2
can deliver then choose IREX.

WHAT
It permits you to [RCL] and [STO]
from/to R00 until R9999 just like 
you would expect.

WHERE
I am trying to find a home for this but
Github is the surest bet.

WHY
I intended to write CTIP - yet another
triangle program - but these needed more
than what R00 to R99 could provide. I 
managed to get something working for 
R00 until R999 . . . but why not the
whole 9-yards since I am already so close.
So I wrote IRE first. 
I could go above R9999 easily but the 
display couldn't.

WHY
I studied FCAT first since I used to 
program the HP-32S and the HP-42S
is a whole new ball game. While I based
IRE on FCAT, it no longer resembles that.
Since this my first public Free42/HP-42S
program, you can see from the flowcharts
how this evolved. I present this as a 
teaching tool for anyone looking to write
their own or modify IREX. FCAT deceptively
uses 50 LBL 14 as a NOP statement. I had 
so much grief over this as a raw beginner. 
I reinvented this by something like "NOP". 
Yeah, in Free42 I can be more extravagant 
with memory.
I use Microsoft Paint as a programming tool
and after a month's absence, I can still
understand how the program works. 2-D is
better than 1-D.

HOW 
First, clear flags 00, 01, 02.
Set REGS to a size that is useful to you.

For me, a certain range is to track the 
amount in my debit card bank account. 
Another range is for alphanumeric passwords.
A third for tallying groceries. I use this
the most. And later on, a range for CTIP
inputs and results. These are usually R100
and above to avoid accidentally encroaching
into the statistics registers. I can never 
remember where they are.

You can also store your "other" telephone
and bank account numbers. For these I 
9's complement them first.

A STRUCTURED WALKTHROUGH that explains
everything about IREX.

Once you XEQ IRE, it assumes the number
in ST X is the indirect address. 

If ST X contains -32665.98432, IRE
begins with R2665.

If you only set R1138 as your highest
register, you will get a "Size Error"
message. The safest is to start with 0.

The initial Menu now shows the following
soft-keys:

[0] [0] [rpt] [Scan] [STO] [STO]

You will quickly see the contents of R00
disappear. This is because I don't know 
how to control that line of the display.

To get that back, press [rpt].

Now press the UP key to get to R01.

Press the DOWN key twice. 

Obvious, isn't it? 

If I wanted to reach R213, that's a 
long way off. No biggie. Just enter
213 and press either [0] [0]. Both 
these keys are equivalent. Same with
both [STO] keys.

Let us do some grocery shopping.
I dislike using the decimal point 
so I leave those out.

First I set aside a range R01 until R20.
Should be enough. 

20
[213]
repeat DOWN until [1] and ensure that all
are 0.

milk 12 1litre carton at 499
499
ENTER
12
x
[STO]

You can see that the pointer advances to
[2] [2].

7kg of cat biscuits at 5965

5965 
[STO]

Revive 7 bottles at 319

319
ENTER
7
X
[STO]

Oops, should be 5 bottles.
Return 2.

319
ENTER
2
X 
+/-
[STO]

2 bottles of 5kg cooking oil.

2630
[ENTER]
2   
X
[STO]

1 bag of drinking chocolate powder mix

1999
[STO]

Do I have enough cash?

Now [Scan] becomes useful.

Since we start with R01 until R20,

1  
STO into register ScMIN
20 
STO into register ScMAX.

Flag 00 must be set. 

The default Flag 00 clear scans
from CURRENT until ScMAX.

In our case, we are only interested
in the range ScMIN until ScMAX.

[Scan]

You get 
ireSUM=20,807
[7] [20] [] [6] [1] [20]

What do these numbers say?

In order,
your shopping cart totals 20,807 cents.
The first empty register is R07.
The last  empty register is R20
The last occupied register is R06.
The range starts from R01
        and ends with R20.
I check my wallet. I have 30000 cents.
Let's STO -30000 into R20.
What does [Scan] show now?

ireSUM=-9,193
[7] [19] [] [20] [1] [20]

I can still add to my shopping cart 
up to 9,193 cents. 
Because I used R20, the last 
empty register is now R19.
I still have room for 
19-7+1=13 transactions. 
If you have several coupons you can
include those as negative cents.

By now you have would used [Scan] 
more than a couple of times.

Bloody slow ain't it?

Well, try setting Flag 01.

What happens if ScMIN > ScMAX?

Try it.

The last trick is the no-brainer
ScMIN = ScMAX.

Keep pressing [Scan].

You will get 
[a random 3-digit number]
  [a throw of a die]
    [a throw of a die]
      [a random 4-digit number]
        [a throw of a die]
          [a throw of a die]

You know how to get out, right?

That's all you get with IRE.

If you want to live dangerously, 
load IREX and set Flag 02.

Once you hit [Scan], you are no
longer in Kansas. 

Everything with MENU2 is dangerous.

But first, the fire exits. 

Keys 7 and 8 or UP and DOWN
are the escape keys. They take you out
of MENU2.

MENU2 has an exact syntax. All
safeties are off and there is no UNDO.

First the syntax. They are completely
intuitive BUT can still get me into trouble.

The MENU2 screen looks like this:
ESC:k7,8,UP,DN
[regX][ssrA][ssrB][ssrR][disR][2scan]

USAGE
5600.0483 
[regX} 

exchanges the contents of R5600 with R483.

USAGE
3465.8864 
[ssrA]

stores 3465 into register ScA1
stores 8864 into register ScA2

USAGE
0123.0342
[ssrB]

stores 0123 into register ScB1
stores 0342 into register ScB2

USAGE
1022.1034
[ssrR]

stores 1022 into register rrr1
stores 1034 into register rrr2

USAGE
101
[disR]

copies the contents of R101 into R1022
copies the contents of R101 into R1023 
                                 .
                                 .
                                 .
copies the contents of R101 into R1033
copies the contents of R101 into R1034

So if R101 contains 0, it is equivalent
to erasing registers R1022 until R1034.

If I wanted to clear my shopping cart,
1.0020
[ssrR]
0
STO 00
[disR]

The example given by HP uses ISG so you 
cannot easily clear above R999.

USAGE
[2Scan]

gives you sumA and sumB.

   sumA is the sum of all the register 
   contents from R3465 until R8864.

   sumB is the sum of all the register 
   contents from R123  until R342.  

WHY?
Because I needed this for CTIP.
WHY?
It's a secret.

END_OF_TEXT

